import { useState } from "react";

export default function Home() {
  const [booking, setBooking] = useState(() => ({
    street: "",
    address: "",
    altTime: "",
    name: "",
    email: "",
    date: "",
    notes: "",
    boogieBoardQty: 0,
    extraChairsQty: 0,
    toyKit: false
  }));

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setBooking((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value
    }));
  };

  const adjustQuantity = (field, delta) => {
    setBooking((prev) => ({
      ...prev,
      [field]: Math.max(0, prev[field] + delta)
    }));
  };

  const mockBookingCounts = {
    "2025-06-21": 3,
    "2025-06-22": 1,
    "2025-06-23": 2
  };

  const handlePayment = async (e) => {
    e.preventDefault();
    const selectedDate = booking.date;
    if (mockBookingCounts[selectedDate] >= 3) {
      alert("This date is no longer available. Please choose another.");
      return;
    }
    try {
      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(booking),
      });
      const data = await res.json();
      if (data?.url) {
        window.location.href = data.url;
      } else {
        console.error("Stripe checkout URL missing", data);
      }
    } catch (error) {
      console.error("Checkout failed", error);
    }
  };

  return (
    <main className="min-h-screen bg-gradient-to-b from-blue-100 to-white text-gray-800">
      {/* Content omitted for brevity. Same as in canvas. */}
    </main>
  );
}
